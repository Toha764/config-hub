-- ============================================================================
-- PLUGIN CONFIGS — smear-cursor
-- ============================================================================

require("smear_cursor").setup({
	smear_between_buffers = true,
	smear_between_neighbor_lines = true,
	scroll_buffer_space = true,
})
