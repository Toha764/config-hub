
require("config.theme")      -- colorscheme + transparency
require("config.options")    -- vim.opt settings
require("config.keymaps")    -- keybindings
require("config.statusline") -- custom statusline
require("config.autocmds")   -- autocommands
require("config.plugins")    -- vim.pack.add + packadd

-- treesitter must come before lsp
require("config.treesitter")
require("config.nvimtree")
require("config.fzf")
require("config.mini")
require("config.gitsigns")
require("config.lsp")        -- LSP + blink.cmp + efm
require("config.terminal")   -- floating terminal

